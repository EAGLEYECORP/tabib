# External services — EAGLEYE CORP CFC
Fill only with contracted provider credentials.
- Supabase: Tech
- Vercel: DevOps
- tabib.ma domain/DNS: IT
- SMS Morocco: Operations
- WhatsApp Business: Operations
- Transactional email: Operations
- MAD payment provider: Finance/Legal
- Maps/geocoding: Product
- Video consultation: Product/Legal
- Monitoring/alerting: DevOps
- Backup/DR: Security
- Privacy/legal validation: Legal
- Penetration test: Security
