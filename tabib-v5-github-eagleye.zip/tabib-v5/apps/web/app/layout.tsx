import './globals.css';
export const metadata={title:'Tabib.ma',description:'Rendez-vous médicaux au Maroc'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
